 <div class="container-fluid mt-5" >
<div class="container text-center text-white con">
<br />
<div class="col-12 mt-5"><h1 class="display-4 text-primary"><u>PORTFOLIO</u></h1></div>
  <div class="row ">
    <div class="col-sm-3 r">
	<div class="card  bg-warning">
      <h3 class=" text-white ">Row Coding</h3>
	  <img src="st/row.jpg" class="ml-4 mb-2" alt="Html,Css,Php"  width="204" height="136"/>
      <p>I can make( responsive)  website by row coding.the language are HTML,CSS & PHP ETC.</p>
      <button type="button" class="btn btn-info"><a href="https://shahensha-aedu.000webhostapp.com/" class="text-white ">To See the websites click here </a></button>
    </div></div>
    <div class="col-sm-3 r">
	<div class="card  bg-warning">
      <h3 class="  text-white ">Wix & WordPress Design</h3>
	  <img src="st/w+w.jpg" class="ml-4 mb-2" alt="wix+ WordPress"  width="204" height="120"/>
      <p>I can Design anytype of Websie by Wix & WordPress </p>
  <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">
    To See the websites click here 
  </button>
</div>
  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Modal Heading</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
		 <ul class="nav nav-tabs btn-group-vertical">
         <li class="nav-item">
		
      <a class="nav-link" href="https://bdfdmn.000webhostapp.com/">WordPress Site</a>
    </li>
	 <li class="nav-item">
      <a class="nav-link" href="https://shafayet133.wixsite.com/ssss">Wix Site</a>
    </li>
	</ul>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  
    </div>
    <div class="col-sm-3 r">
	<div class="card  bg-warning">
      <h3 class="  text-white ">laravel</h3>
	  <img src="st/ss.png" class="ml-4 mb-2" alt="wix+ WordPress"  width="204" height="136"/>
      <p>I can  Design and Development anytype of Websie by laravel. this site also make by laravel </p>
      <button type="button" class="btn btn-info"><a href="http://localhost/pro/" class="text-white ">To See the websites click here </a></button>
    </div>
	</div>
	  <div class="col-sm-3 r">
	  <div class="card  bg-warning">
   <h3 class="  text-white ">Video And Photo Editing</h3>
	  <img src="st/v.jpg" class="ml-4 mb-2" alt="wix+ WordPress"  width="204" height="120"/>
      <p>I can Edit any type of video and Photo.Even Green Screen Video  </p>
      <button type="button" class="btn btn-info"><a href="https://www.youtube.com/channel/UCpczXgLBfwvR4Pr0bKsBM5A/videos" class="text-white ">To See the websites click here </a></button>
    </div></div>
  </div>
</div>
</div>