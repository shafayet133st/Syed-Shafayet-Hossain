
   <div class="container-fluid bg-dark mt-5" >
<div class="container  ">
    <div class="row">

		
    <div class="col-sm-6">
<div class="text-center text-white"> <h1> <u>PROFESSIONAL skills</u></h1></div>

<table class="table table-borderless">
    <tbody>
      <tr>
        <td style="width: 20%;"><h4 class=" bg-success text-center text-white ">PHP</h4></td>
     
        <td><div class="progress mt-2" style="width: 80%;">
		
    <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" style="width:90%">90%</div>
  </div></td>
      <tr>
        <td style="width: 20%;"><h4 class=" bg-info text-center text-white ">HTML</h4></td>
     
        <td><div class="progress mt-2" style="width: 80%;">
		
    <div class="progress-bar bg-info progress-bar-striped progress-bar-animated" style="width:85%">85%</div>
  </div></td>
      </tr>
	       <tr>
        <td style="width: 20%;"><h4 class=" bg-warning text-center text-white ">CSS</h4></td>
     
        <td><div class="progress mt-2" style="width: 80%;">
		
    <div class="progress-bar bg-warning progress-bar-striped progress-bar-animated" style="width:85%">85%</div>
  </div></td>
      </tr>
	  	  	<tr>
        <td style="width: 20%;"><h4 class=" bg-light text-center  ">SQL</h4></td>
     
        <td><div class="progress mt-2" style="width: 80%;">
		
    <div class="progress-bar bg-dark progress-bar-striped progress-bar-animated" style="width:80%">80%</div>
  </div></td>
      </tr>	
	<tr>
        <td style="width: 20%;"><h4 class=" bg-primary text-center text-white ">Bootstrap 4</h4></td>
     
        <td><div class="progress mt-2" style="width: 80%;">
		
    <div class="progress-bar bg-primary progress-bar-striped progress-bar-animated" style="width:85%">85%</div>
  </div></td>
      </tr>


	  	<tr>
        <td style="width: 20%;"><h4 class=" bg-success text-center  text-white">Wordpress Customization</h4></td>
     
        <td><div class="progress mt-2" style="width: 80%;">
		
    <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" style="width:85%">85%</div>
  </div></td>
      </tr>
	  	<tr>
        <td style="width: 20%;"><h4 class=" bg-danger text-center text-white ">Laravel</h4></td>
     
        <td><div class="progress mt-2" style="width: 80%;">
		
    <div class="progress-bar bg-danger progress-bar-striped progress-bar-animated " style="width:95%">95%</div>
  </div></td>
      </tr>	
	  	<tr>
        <td style="width: 20%;"><h4 class=" bg-info text-center text-white ">Video Editing</h4></td>
     
        <td><div class="progress mt-2 " style="width: 80%;">
		
    <div class="progress-bar bg-info progress-bar-striped progress-bar-animated" style="width:70%">70%</div>
  </div></td>
      </tr>
	  	<tr>
        <td style="width: 20%;"><h4 class=" bg-secondary text-center text-white ">Photo Editing</h4></td>
     
        <td><div class="progress mt-2" style="width: 80%;">
		
    <div class="progress-bar bg-secondary progress-bar-striped progress-bar-animated" style="width:70%">70%</div>
  </div></td>
      </tr>	  
    </tbody>
  </table>
    </div>
	    <div class="col-sm-6 text-white">
<div class="col-12"><h1 class=" text-center text-uppercase"> <u>experience</u></h1></div>
<div class="row mt-3 ">
 <div class="col-sm-6"> <h5>3i template It Solutions</h5> <p>Internship</p>
 </div>
  <div class="col-sm-6">  <p>It is a hospital based software company.I was learning about Oracle Database and SQL Database and I was helping customer support companies like restarting Oracle, getting backups, restoring backup files, etc. I sometimes even had to go to the hospital (Customer of that 3i template It Solutions)</p>
 </div>

 <!---edu-->
  <div class="col-sm-6"> <h5>Eduleam</h5> <p>Executive (software & Wordpress Developer )</p>
 </div>
  <div class="col-sm-6">  <p>This is an education based software company Here, I was supporting software frontend, and gather information and data entry and sometimes i was supporting the customer support employee.</p>
 </div>
  <!---sha-->
  <div class="col-sm-6"> <h5>Shahensha-A-IT</h5> <p>Web Design & Developer</p>
 </div>
  <div class="col-sm-6">  <p>I am Full Stack Web Developer since 2018 july And CMS Developer 2019 september.</p>
 </div>
   <!---fiver-->
  <div class="col-sm-6"> <h5>Fiver</h5><p>Freelance</p> <p>Web Design & Developer</p>
 </div>
  <div class="col-sm-6 ">  <p>I am a freelancer at fiverr. I want take it as a full profession. In am work as web designer, web developer. facebook marketer and wordpress customizer</p>
 </div>
</div>
		</div>
		</div>
	</div>
	
	<br />
</div>