<div class="container mt-3 mt-5 ">
<div class="col-12"><h1 class="display-4 text-center text-uppercase text-success"> <u>My Work</u> </h1></div>
<div class="row">
  <!-- Nav tabs -->
   <div class="col-sm-3 clear">
 <div class=" card ca">
 <img src="st/ddd.JPG" alt="" />
    <div class="card-body">Laravel E-commerce website</div>
		  <div class="shado">

	<p>
	<u class="text-center">functionality</u><br />
*fully funtional e-comarce websit (laravel)<br />
*full design and develop .fully responsive and dynamic<br />
*any type of edit and develop totally free in 3 month<br />
*Easy to add products , Easy to add category  & Easy to add brand <br />
*Easy to add  slider image and add button in slide<br />
*fully user friendly	<br />
<a href=""><button class="bg-danger text-white ba">see video</button></a><a href=""><button class="bg-primary text-white ba">see deomo</button></a>
	</p>
	</div>
  </div>
  </div>
   <div class="col-sm-3 clear">
 <div class= "card ca ">
 <img src="st/Homepage.png" alt="" />
    <div class="card-body">Core Php & java rent car </div>
	  <div class="shado">

	<p>
	<u >functionality</u><br />
	1.automatic address come like google map. <br />
    2.take two place address and find the distance and customer can select any type of car. <br />
3.show car price accouding to (per mile price of the car* mile + ...). <br />
4.then it show login or registration.
5.then my account it take all kind of credit card.(owner mast have a strip account) <br />	
<a href=""><button class="bg-danger text-white ba">see video</button></a><a href=""><button class="bg-primary text-white ba">see deomo</button></a>
	</p>
	</div>
  </div>

  </div>
   <div class="col-sm-3 clear">
   <div class=" card ca ">
 <img src="st/cms.JPG" alt="" />
    <div class="card-body">school management system  </div>
		  <div class="shado">

	<p>
	<u >functionality</u><br />
1. Automatic result and generate mark sheet, Generate automatic monthly fees and fee sheets.<br />
3. Automatic exam admission card generated. (Students who pay monthly fee only)<br />
4. Automatically generate total account. For example, how much did you receive, how much did you spend, and how much money do you have now? <b class="text-danger">many more</b><br />
<a href=""><button class="bg-danger text-white ba">see video</button></a><a href=""><button class="bg-primary text-white ba">see deomo</button></a>
	</p>
	</div>
  </div>
  </div>
   <div class="col-sm-3 clear">
     <div class=" card ca">
 <img src="st/hg.JPG" alt="" />
    <div class="card-body">Wordpress news paper website  </div>
			  <div class="shado">

	<p>
	<u >functionality</u><br />
	1.it is a wordpress newspaper website. fully customized. <br />
2. you can post news every day or monthly. <br />
3. you can give own ads or google google adsense ads. <br />
4.you can use it as daily,weekly or monthy news paper or magazin. <br />
5. As because it is a wordpress websit so it is fully responsive and user friendly <br />	
<a href=""><button class="bg-danger text-white ba">see video</button></a><a href=""><button class="bg-primary text-white ba">see deomo</button></a>
	</p>
	</div>
  </div>
  </div>
  </div>
</div>