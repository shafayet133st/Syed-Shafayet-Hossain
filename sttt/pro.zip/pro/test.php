<!DOCTYPE html>
<html lang="en">
<head>
  <title>My Work</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet"  type="text/css"href="css/style.php">
    <style>
  /* Make the image fully responsive */
  .carousel-inner img {
    width: 100%;
    height: 50%;
  }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-md  navbar-light bg-light  sticky-top">
<div class="container-fluid">
<a class="navbar-brand" href="index.php"><img src="st/lo.jpg" alt=""  width="50px" height="50px" /></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
 <span class="nav-toggler-icon"></span>
</button>

<div class=" collapse navbar-collapse" id="navbarResponsive">
<ul class="navbar-nav ml-auto">
   <li class="nav-item  active">
      <a class="nav-link" href="index.php">HOME</a>
    </li>
    <li class="nav-item ">
      <a class="nav-link" href="#">Link</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Link</a>
    </li>
  </ul>
   </div>
 </div>
 </nav>
 <h2 class="text-center text-primary">Some of  My Website & Managemant System</h2>
 
<div class="container">
<h3 class=" bg-secondary text-center text-white ">Ecommerce Website</h3>
<div class="row">

	 <div class="col-md-12"><iframe width="100%" height="500" src="http://www.shammabs.com/" frameborder="0" ></iframe></div>
	  <div class="pl-5"><a href="http://www.shammabs.com/"><button class="bg-info text-white p-2"> For go to the site</button></a></div>
	  <h4 class="text-justify">I design and develop this website for a beauty  Parlour .I didn't use any type of framework or CMS. To make  this website,I use row php ,HTML, CSS, jQuery & Bootstrap 4    </h4>
	  
	  </div>
  
  

<br />
 <h3 class=" bg-secondary text-center text-white ">WordPress Website</h3>
<div class="row">

	 <div class="col-md-12"><iframe width="100%" height="500" src="https://bdfdmn.000webhostapp.com/" frameborder="0" ></iframe></div>
	  <div class="pl-5"><a href="https://bdfdmn.000webhostapp.com/"><button class="bg-info text-white p-2"> For go to the site</button></a></div>
	  <h4 class="text-justify">I design and develop this website for a project .It  is a wordpress website. </h4>
	  
	  </div>
  
  

<br />

<h3 class=" bg-secondary text-center text-white ">School Website</h3>
<div class="row">

	 <div class="col-md-12"><iframe width="100%" height="500" src="http://smsst.000webhostapp.com/" frameborder="0" ></iframe></div>
	  <div class="pl-5"><a href="http://smsst.000webhostapp.com/"><button class="bg-info text-white p-2"> For go to the site</button></a></div>
	  <h4 class="text-justify">I didn't use any type of famwork or CMS  here. To make  this website,I used  php  ,HTML, CSS & Bootstrap 4   </h4>
	  
	  </div>
<br />
  
<h3 class=" bg-dark text-center text-white ">School Managemant  System</h3><br />
<div class="row">

	 <div class="col-md-9"><iframe width="100%" height="315" src="http://smsst.000webhostapp.com/sec/soft/" frameborder="0" ></iframe></div>
	  <div class="col-md-3"><div class="pl-5"><a href="http://smsst.000webhostapp.com/sec/soft/"><button class="bg-info text-white p-2"> For go to the site</button></a></div>
	  <h4 class="text-justify">I didn't use any type of famwork or CMS  here. To make  this website,I used  php ,HTML, CSS & Bootstrap 4  
</h4><h6>
<br />username	:--shafayet
<br />Emai:--shafayet133@gmail.com 
<br />password	:--123456 </h6>
	  
	  </div>
  
  
</div>
<br />
  
<h3 class=" bg-dark text-center text-white "> Bakery Managemant  System</h3><br />
<div class="row">

	 <div class="col-md-9"><iframe width="100%" height="315" src="http://stfac.000webhostapp.com/sec/soft/" frameborder="0" ></iframe></div>
	  <div class="col-md-3"><div class="pl-5"><a href="http://stfac.000webhostapp.com/sec/soft/"><button class="bg-info text-white p-2"> For go to the site</button></a></div>
	  <h4 class="text-justify">I didn't use any type of famwork or CMS  here. To make  this website,I used  php ,HTML, CSS & Bootstrap 4  
</h4><h6>
<br />username	:--shafayet
<br />Emai:--shafayet133@gmail.com 
<br />password	:--123456 </h6>
	  
	  </div>
  
  
</div>
  
</div>
  <div class="container bg-dark ">
 <div class="text-center text-white"> <h5>Power by &#169; S@yed shafayet hossain</h5></div>
 </div>
</body>
</html>
